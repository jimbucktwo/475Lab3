﻿document.addEventListener('DOMContentLoaded', function () {
    var holidayForm = document.getElementById('holidayForm');
    holidayForm.addEventListener('submit', function (e) {
        e.preventDefault();
        var hr = new XMLHttpRequest;
        var year = document.getElementById('txtYear').value;
        var countryCode = document.getElementById('txtCountryCode').value;
        hr.open('GET', '/Home/Index?countryCode=' + countryCode + '&year=' + year, true);

        hr.onreadystatechange = function () {
            if (hr.readyState === XMLHttpRequest.DONE) {
                if (hr.status === 200) {
                    var tableElement = document.createElement('div');
                    tableElement.innerHTML = hr.responseText;
                    var table = tableElement.querySelector('.table.table-bordered.table-striped.table-sm');
                    document.getElementById('holidayResults').innerHTML = table.outerHTML;

                } else {
                    console.error('Error loading page:', hr.statusText);
                }
            }

            };
            hr.send();
        });
    });