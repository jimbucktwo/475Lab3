﻿using cecs475_lab3.Models;

namespace cecs475_lab3
{
    public interface IHolidaysApiService
    {
        Task<List<HolidayModel>> GetHolidays(string countryCode, int year);
    }
}
